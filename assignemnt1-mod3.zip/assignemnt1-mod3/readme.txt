The file process.php provided here is unnecessary. As indicated in the end-of-chapter instructions on pages 236-237, it can be accessed via the url:

http://www.randyconnolly.com/tests/process.php.

The source code for this PHP page have been provided to mainly satisfy your intellectual curiosity; if, for some reason the above URL doesn't work, you can put it on some other PHP-enabled web server and test the submit actions of these three projects.