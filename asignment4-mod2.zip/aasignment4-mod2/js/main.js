document.addEventListener('DOMContentLoaded', () => {
    console.log('Main JS loaded');
});