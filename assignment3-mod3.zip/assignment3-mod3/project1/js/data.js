/* here is the array used for project 1 */

const cart = [
      {
            product: {
                  title: "Portrait of Marten Soolmans",
                  filename: "105070.jpg",
                  price: 75.0
            },
            quantity: 3
      },
      {
            product: {
                  title: "View of Houses in Delft",
                  filename: "106060.jpg",
                  price: 125.0
            },
            quantity: 1
      },
      {
            product: {
                  title: "Woman Reading a Letter",
                  filename: "106050.jpg",
                  price: 100.0
            },
            quantity: 2
      },      
];
    