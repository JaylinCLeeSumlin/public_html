// Exercise 1
console.log("Hello, JavaScript World!")

// Exercise 2
let a = 20;
let b = 5;

console.log("Addition:", a + b);
console.log("Subtraction:", a - b);
console.log("Multiplication:", a * b);
console.log("Division:", a / b);

// Exercise 3
function greet(name) {
    return "Hello," + name + "!";
}
console.log(greet("Alice"));
console.log(greet("Bob"));
console.log(greet("Jaylin"))